#ifndef __usart_H
#define __usart_H

#include "system.h" 
#include "stdio.h" 

void USART1_Init(u32 bound);
extern u8 s[37];
extern u8 b;
extern u8 star;
#endif


